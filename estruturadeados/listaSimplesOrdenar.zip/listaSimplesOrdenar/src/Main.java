import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static String primeiraStringEmOrdemAlfabetica(String str1, String str2) {
        int minLength = Math.min(str1.length(), str2.length());
        for (int i = 0; i < minLength; i++) {
            char char1 = str1.charAt(i);
            char char2 = str2.charAt(i);
            if (char1 < char2) {
                return str1;
            } else if (char1 > char2) {
                return str2;
            }
        }
        if (str1.length() < str2.length()) {
            return str1;
        } else if (str1.length() > str2.length()) {
            return str2;
        } else {
            return "As strings são iguais.";
        }
    }

    public static void quickSort(List<String> list, int low, int high) {
        if (low < high) {
            int pi = partition(list, low, high);
            quickSort(list, low, pi-1);
            quickSort(list, pi+1, high);
        }
    }

    private static int partition(List<String> list, int low, int high) {
        String pivot = list.get(high);
        int i = (low-1);
        for (int j = low; j < high; j++) {
            if (list.get(j).compareTo(pivot) < 0) {
                i++;
                String temp = list.get(i);
                list.set(i, list.get(j));
                list.set(j, temp);
            }
        }
        String temp = list.get(i+1);
        list.set(i+1, list.get(high));
        list.set(high, temp);
        return i+1;
    }

    public static void selectionSort(List<String> list) {
        int n = list.size();
        for (int i = 0; i < n-1; i++) {
            int minIdx = i;
            for (int j = i+1; j < n; j++) {
                if (list.get(j).compareTo(list.get(minIdx)) < 0) {
                    minIdx = j;
                }
            }
            String temp = list.get(minIdx);
            list.set(minIdx, list.get(i));
            list.set(i, temp);
        }
    }

    public static void main(String[] args) {
        List<String> senhas = new ArrayList<>();
        try {
            File myObj = new File("senhas.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String senha = myReader.nextLine().replaceAll("[0-9]", "").replaceAll("\\s+", "");
                senhas.add(senha);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("Ocorreu um erro.");
            e.printStackTrace();
        }

        long inicio, fim;

        // Ordenação com Selection Sort
        inicio = System.currentTimeMillis();
        selectionSort(senhas);
        fim = System.currentTimeMillis();
        System.out.println("Tempo Selection Sort: " + (fim - inicio) + " ms");

        // Recarregar as senhas para garantir a mesma entrada para o próximo teste
        senhas.clear();
        try {
            File myObj = new File("senhas.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String senha = myReader.nextLine().replaceAll("[0-9]", "").replaceAll("\\s+", "");
                senhas.add(senha);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("Ocorreu um erro.");
            e.printStackTrace();
        }

        // Ordenação com Quick Sort
        inicio = System.currentTimeMillis();
        quickSort(senhas, 0, senhas.size() - 1);
        fim = System.currentTimeMillis();
        System.out.println("Tempo Quick Sort: " + (fim - inicio) + " ms");
    }
}
